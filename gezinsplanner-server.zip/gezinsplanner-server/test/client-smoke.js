'use strict';
/* Laat de echte app-code (public/index.html + net.js) draaien met een nagebootste browser
   tegen de echte server. Dit is geen vervanging voor testen op een telefoon. */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');

process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'gp-smoke-'));
const server = require('../server.js');
const html = fs.readFileSync(path.join(__dirname, '../public/index.html'), 'utf8');
const netjs = fs.readFileSync(path.join(__dirname, '../public/net.js'), 'utf8');
const appjs = /<script>\n([\s\S]*?)<\/script>/.exec(html)[1];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const until = async (f, ms = 4000) => { const t = Date.now(); while (Date.now() - t < ms) { const v = await f(); if (v) return v; await sleep(40); } throw new Error('time-out: ' + f.toString().slice(0, 80)); };

function makeBrowser(base, preset) {
  const els = {};
  const el = (k) => els[k] || (els[k] = { innerHTML: '', textContent: '', className: '', style: {}, srcObject: null, dataset: {}, disabled: false, focus() {}, setAttribute() {}, removeAttribute() {} });
  const store = new Map(Object.entries(preset || {}));
  const localStorage = { getItem: (k) => (store.has(k) ? store.get(k) : null), setItem: (k, v) => store.set(k, String(v)), removeItem: (k) => store.delete(k) };
  const root = { style: { setProperty() {}, removeProperty() {} }, setAttribute() {}, removeAttribute() {} };
  const document = {
    querySelector: (s) => el(s), querySelectorAll: () => [], documentElement: root,
    activeElement: { tagName: 'BODY' }, addEventListener() {}, createElement: () => ({ click() {} }),
  };
  const win = {};
  const ctx = vm.createContext({
    window: win, document, localStorage, console, setTimeout, clearTimeout, setInterval, clearInterval,
    fetch: (u, o) => fetch(String(u).startsWith('/') ? base + u : u, o),
    AbortController, TextDecoder, TextEncoder, URL, Blob, Date, Math, JSON, Promise, Set, Map, Array, Object, String, Number, RegExp, Error,
    navigator: { mediaDevices: {}, vibrate() {} }, location: { protocol: 'http:', hostname: 'localhost', origin: base, pathname: '/', hash: '' },
    matchMedia: () => ({ matches: false, addEventListener() {} }), scrollTo() {}, addEventListener() {},
    structuredClone, encodeURIComponent, parseFloat, isNaN, RTCPeerConnection: function () {},
  });
  ctx.window = ctx; ctx.self = ctx;
  vm.runInContext(netjs, ctx);
  vm.runInContext(appjs, ctx);
  return { ctx, el, run: (code) => vm.runInContext(code, ctx), store };
}

(async () => {
  await new Promise((ok) => server.listen(0, '127.0.0.1', ok));
  const base = 'http://127.0.0.1:' + server.address().port;
  try {
    /* telefoon 1: nieuw gezin */
    const A = makeBrowser(base);
    assert.match(A.el('#app').innerHTML, /Welkom/, 'inlogscherm zichtbaar');
    assert.match(A.el('#app').innerHTML, /Nieuw gezin/);
    A.run("U.au.m='new';U.au.g='Smoke gezin';U.au.n='Vader';U.au.p='smoke-wachtwoord';act('auth')");
    await until(() => A.run('!!cur()&&!BOOT'));
    assert.equal(A.run('cur().r'), 'b', 'maker is beheerder');
    assert.ok(!/Welkom/.test(A.el('#app').innerHTML), 'hoofdscherm zichtbaar');
    const code = A.run('S.ic');
    assert.match(code, /^[A-Z2-9]{6}$/, 'beheerder ziet uitnodigingscode');
    assert.ok(A.run("typeof NET.cid==='string'") || await until(() => A.run("typeof NET.cid==='string'")), 'live verbinding');

    /* telefoon 2: kind doet mee met de code */
    const B = makeBrowser(base);
    B.run(`U.au.m='join';U.au.f='${code}';U.au.n='Sam';U.au.p='1234';act('auth')`);
    await until(() => B.run('!!cur()&&!BOOT'));
    assert.equal(B.run('cur().r'), 'k');
    assert.equal(B.run('S.ic'), '', 'kind ziet de code niet');
    await until(() => A.run('M.length') === 2, 4000);          // telefoon 1 ziet de nieuwe gezinsleden live
    const samId = B.run('ME');

    /* beheerder maakt taak voor Sam; Sam ziet die live */
    A.run(`U.nc.t='Afwas';U.nc.w='${samId}';U.nc.p='2';act('addch')`);
    await until(() => B.run('S.ch.length') === 1, 4000);
    assert.equal(B.run('S.ch[0].t'), 'Afwas');

    /* Sam vinkt af -> punten, en de beheerder ziet dat live */
    B.run(`act('tch','${B.run('S.ch[0].id')}')`);
    await until(() => A.run('S.ch[0].x') === 1 && A.run('S.lg.length') === 1, 4000);

    /* kind probeert een taak toe te voegen: de app blokkeert het zelf al */
    B.run("U.nc.t='Gratis';U.nc.w=ME;act('addch')");
    await sleep(700);
    assert.equal(A.run('S.ch.length'), 1, 'geen extra taak');

    /* beide telefoons zien elkaar bij Bellen */
    await until(() => A.run('R.peers().length') === 2 && B.run('R.peers().length') === 2, 4000);
    assert.equal(A.run("R.peers().filter(p=>!p.sameTab).length"), 1);

    /* alle schermen tekenen zonder fout, als beheerder en als kind */
    for (const [who, b] of [['beheerder', A], ['kind', B]]) {
      for (const k of b.run('Object.keys(V)')) {
        b.run(`U.v='${k}';render()`);
        assert.ok(b.el('#app').innerHTML.length > 200, `${who}: scherm ${k} is leeg`);
      }
      b.run("U.v='vandaag';render()");
    }
    assert.match(A.run("U.v='profiel';U.o.acc=true;render();$('#app').innerHTML"), /Mijn account/);
    assert.match(A.run("$('#app').innerHTML"), /Gezin definitief verwijderen/, 'beheerder ziet verwijderknop');
    assert.ok(!/Gezin definitief verwijderen/.test(B.run("U.v='profiel';U.o.acc=true;render();$('#app').innerHTML")), 'kind niet');
    A.run("U.v='vandaag';render()");
    B.run("U.v='vandaag';render()");

    /* uitloggen en weer inloggen met verkeerde en goede code */
    B.run("act('switch')");
    assert.match(B.el('#app').innerHTML, /Welkom/);
    B.run(`U.au.m='login';U.au.f='${code}';U.au.n='Sam';U.au.p='fout';act('auth')`);
    await sleep(500);
    assert.ok(!B.run('!!cur()'), 'foute code komt er niet in');
    B.run(`U.au.p='1234';act('auth')`);
    await until(() => B.run('!!cur()&&!BOOT'));
    assert.equal(B.run('S.ch.length'), 1, 'gegevens staan er weer');

    /* app opnieuw openen met bewaarde sessie: gegevens worden zelf opgehaald */
    const C = makeBrowser(base, { gp_session: B.store.get('gp_session') });
    assert.match(C.el('#app').innerHTML, /Even laden/);
    await until(() => C.run('!!cur()&&!BOOT'));
    assert.equal(C.run('S.ch.length'), 1);
    console.log('client smoke: alles OK');
  } catch (e) {
    console.error('client smoke: MISLUKT\n', e);
    process.exitCode = 1;
  } finally {
    server.closeAllConnections?.(); server.close(); setTimeout(() => process.exit(process.exitCode || 0), 300);
  }
})();
