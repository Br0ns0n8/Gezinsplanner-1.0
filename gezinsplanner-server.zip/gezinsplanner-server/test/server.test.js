'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'gp-test-'));
process.env.DATA_DIR = DATA;
const server = require('../server.js');

let base;
test.before(() => new Promise((ok) => server.listen(0, '127.0.0.1', () => { base = 'http://127.0.0.1:' + server.address().port; ok(); })));
test.after(() => { server.closeAllConnections?.(); server.close(); });

async function call(method, p, body, token, cid) {
  const h = { 'Content-Type': 'application/json' };
  if (token) h.Authorization = 'Bearer ' + token;
  if (cid) h['X-Client'] = cid;
  const r = await fetch(base + p, { method, headers: h, body: body ? JSON.stringify(body) : undefined });
  let d = {}; try { d = await r.json(); } catch {}
  return { status: r.status, ...d };
}

/* kleine SSE-lezer */
async function openEvents(token) {
  const ac = new AbortController();
  const r = await fetch(base + '/api/events', { headers: { Authorization: 'Bearer ' + token }, signal: ac.signal });
  const events = [], waiters = [];
  (async () => {
    const rd = r.body.getReader(), dec = new TextDecoder(); let buf = '';
    try {
      for (;;) {
        const { value, done } = await rd.read(); if (done) break;
        buf += dec.decode(value, { stream: true });
        let i;
        while ((i = buf.indexOf('\n\n')) >= 0) {
          const blk = buf.slice(0, i); buf = buf.slice(i + 2);
          const ev = /event: (.*)/.exec(blk), da = /data: (.*)/.exec(blk);
          if (ev && da) { const e = { ev: ev[1], data: JSON.parse(da[1]) }; events.push(e); waiters.slice().forEach((w) => w(e)); }
        }
      }
    } catch {}
  })();
  const waitFor = (name, pred = () => true, ms = 3000) => new Promise((ok, no) => {
    const hit = events.find((e) => e.ev === name && pred(e.data));
    if (hit) return ok(hit.data);
    const t = setTimeout(() => no(new Error('geen event: ' + name)), ms);
    const w = (e) => { if (e.ev === name && pred(e.data)) { clearTimeout(t); waiters.splice(waiters.indexOf(w), 1); ok(e.data); } };
    waiters.push(w);
  });
  return { events, waitFor, close: () => ac.abort() };
}

let admin, kid, code, adminState;

test('gezin aanmaken, meedoen en inloggen', async () => {
  const short = await call('POST', '/api/family', { familyName: 'Test', name: 'Papa', password: 'kort' });
  assert.equal(short.status, 400);

  const f = await call('POST', '/api/family', { familyName: 'Familie Test', name: 'Papa', password: 'veiligwachtwoord', color: '#2E86AB' });
  assert.equal(f.status, 201);
  admin = f;
  const st = await call('GET', '/api/state', null, admin.token);
  assert.equal(st.status, 200);
  code = st.state.ic;
  assert.match(code, /^[A-Z2-9]{6}$/);
  adminState = st.state;

  assert.equal((await call('POST', '/api/join', { code: 'XXXXXX', name: 'Sam', password: '1234' })).status, 404);
  const j = await call('POST', '/api/join', { code: code.toLowerCase(), name: 'Sam', password: '1234', color: '#3E9B4F' });
  assert.equal(j.status, 201);
  kid = j;
  assert.equal(kid.user.role, 'k');
  assert.equal((await call('POST', '/api/join', { code, name: 'sam', password: '9999' })).status, 409, 'dubbele naam');

  const l = await call('POST', '/api/login', { code, name: ' SAM ', password: '1234' });
  assert.equal(l.status, 200);
  assert.equal((await call('POST', '/api/login', { code, name: 'Sam', password: '0000' })).status, 401);
  assert.equal((await call('GET', '/api/state')).status, 401, 'zonder token');
  assert.equal((await call('GET', '/api/state', null, 'nep.token')).status, 401);
});

test('uitnodigingscode en leden: alleen de beheerder ziet de code', async () => {
  const k = await call('GET', '/api/state', null, kid.token);
  assert.equal(k.state.ic, undefined);
  assert.equal(k.state.mb.length, 2);
  assert.ok(k.state.mb.every((m) => m.acc === true));
  assert.ok(k.state.mb.every((m) => m.pin === undefined));
});

test('rechten: kind mag niet alles, en krijgt de echte stand terug', async () => {
  const kst = (await call('GET', '/api/state', null, kid.token)).state;
  const adm = (await call('GET', '/api/state', null, admin.token)).state;

  // beheerder maakt een taak voor Sam en een voor Papa
  const sam = kst.mb.find((m) => m.n === 'Sam').id, papa = adm.mb.find((m) => m.n === 'Papa').id;
  adm.ch = [{ id: 1, t: 'Afwas', w: sam, p: 2, x: 0 }, { id: 2, t: 'Afval', w: papa, p: 1, x: 0 }];
  const a1 = await call('PUT', '/api/state', { state: adm }, admin.token);
  assert.equal(a1.status, 200);
  assert.equal(a1.changed, undefined);

  // kind vinkt eigen taak af, probeert andermans taak af te vinken, een taak toe te voegen en zichzelf beheerder te maken
  const s = (await call('GET', '/api/state', null, kid.token)).state;
  s.ch[0].x = 1; s.ch[1].x = 1;
  s.ch.push({ id: 3, t: 'Gratis punten', w: sam, p: 99, x: 0 });
  s.mb.find((m) => m.id === sam).r = 'b';
  s.ev.push({ id: 10, t: 'Zwemmen', d: '2026-10-30', h: '16:00', w: [sam] });
  s.ic = 'HACKED';
  const r = await call('PUT', '/api/state', { state: s }, kid.token);
  assert.equal(r.status, 200);
  assert.equal(r.changed, true, 'client krijgt te horen dat er iets is teruggezet');
  const after = (await call('GET', '/api/state', null, admin.token)).state;
  assert.equal(after.ch.length, 2, 'geen extra taak');
  assert.equal(after.ch[0].x, 1, 'eigen taak afgevinkt');
  assert.equal(after.ch[1].x, 0, 'andermans taak niet');
  assert.equal(after.mb.find((m) => m.id === sam).r, 'k', 'rol niet aangepast');
  assert.equal(after.ev.length, 1, 'afspraak plannen mag wel');
  assert.notEqual(after.ic, 'HACKED');
});

test('beheerder past rollen aan; gast mag alleen kijken', async () => {
  const adm = (await call('GET', '/api/state', null, admin.token)).state;
  const sam = adm.mb.find((m) => m.n === 'Sam');
  sam.r = 'v';
  assert.equal((await call('PUT', '/api/state', { state: adm }, admin.token)).status, 200);
  // rol is veranderd: oude token van Sam is ongeldig, opnieuw inloggen geeft nieuwe rol
  assert.equal((await call('GET', '/api/state', null, kid.token)).status, 401);
  const l = await call('POST', '/api/login', { code, name: 'Sam', password: '1234' });
  assert.equal(l.user.role, 'v');
  const s = (await call('GET', '/api/state', null, l.token)).state;
  s.ev.push({ id: 11, t: 'Mag niet', d: '2026-10-31', w: [] });
  assert.equal((await call('PUT', '/api/state', { state: s }, l.token)).status, 403);
  kid = l;
});

test('laatste beheerder kan zichzelf niet degraderen; leden verwijderen sluit hun account', async () => {
  const adm = (await call('GET', '/api/state', null, admin.token)).state;
  adm.mb.find((m) => m.n === 'Papa').r = 'k';
  await call('PUT', '/api/state', { state: adm }, admin.token);
  assert.equal((await call('GET', '/api/state', null, admin.token)).state.mb.find((m) => m.n === 'Papa').r, 'b');

  const cur = (await call('GET', '/api/state', null, admin.token)).state;
  cur.mb = cur.mb.filter((m) => m.n !== 'Sam');
  await call('PUT', '/api/state', { state: cur }, admin.token);
  assert.equal((await call('GET', '/api/state', null, kid.token)).status, 401);
  assert.equal((await call('POST', '/api/login', { code, name: 'Sam', password: '1234' })).status, 401);
});

test('wachtwoord wijzigen en resetten maakt oude toestellen ongeldig', async () => {
  const j = await call('POST', '/api/join', { code, name: 'Noor', password: '4321' });
  assert.equal(j.status, 201);
  const noorMid = j.user.mid;
  assert.equal((await call('POST', '/api/password', { old: 'fout', password: '5555' }, j.token)).status, 403);
  const p = await call('POST', '/api/password', { old: '4321', password: '5555' }, j.token);
  assert.equal(p.status, 200);
  assert.equal((await call('GET', '/api/me', null, j.token)).status, 401, 'oude token ongeldig');
  assert.equal((await call('GET', '/api/me', null, p.token)).status, 200, 'nieuwe token werkt');

  assert.equal((await call('POST', '/api/reset', { mid: noorMid, password: '7777' }, p.token)).status, 403, 'kind mag niet resetten');
  assert.equal((await call('POST', '/api/reset', { mid: noorMid, password: '7777' }, admin.token)).status, 200);
  assert.equal((await call('POST', '/api/login', { code, name: 'Noor', password: '5555' })).status, 401);
  assert.equal((await call('POST', '/api/login', { code, name: 'Noor', password: '7777' })).status, 200);
});

test('te veel foute pogingen worden geblokkeerd', async () => {
  let last;
  for (let i = 0; i < 10; i++) last = await call('POST', '/api/login', { code, name: 'Noor', password: 'fout' + i });
  assert.equal(last.status, 429);
  // ook het juiste wachtwoord helpt dan even niet
  assert.equal((await call('POST', '/api/login', { code, name: 'Noor', password: '7777' })).status, 429);
});

test('live: wijzigingen en bellen-berichten gaan alleen binnen het gezin', async () => {
  // tweede gezin
  const other = await call('POST', '/api/family', { familyName: 'Anderen', name: 'Ander', password: 'ander-wachtwoord' });
  const mama = await call('POST', '/api/join', { code, name: 'Mama', password: '2468' });
  assert.equal(mama.status, 201);

  const A = await openEvents(admin.token), B = await openEvents(mama.token), O = await openEvents(other.token);
  const ha = await A.waitFor('hello'), hb = await B.waitFor('hello'), ho = await O.waitFor('hello');
  const peers = await A.waitFor('peers', (p) => p.length === 2);
  assert.deepEqual(peers.map((p) => p.mid).sort(), [admin.user.mid, mama.user.mid].sort(), 'aanwezigheid komt van de server');

  // wijziging van A bereikt B, niet O, en niet A zelf
  const st = (await call('GET', '/api/state', null, admin.token)).state;
  st.li.Boodschappen.push({ t: 'Melk', x: 0 });
  const put = await call('PUT', '/api/state', { state: st }, admin.token, ha.cid);
  const ev = await B.waitFor('state', (d) => d.rev === put.rev);
  assert.equal(ev.rev, put.rev);
  await new Promise((r) => setTimeout(r, 150));
  assert.ok(!O.events.some((e) => e.ev === 'state' && e.data.rev === put.rev), 'ander gezin ziet niets');
  assert.ok(!A.events.some((e) => e.ev === 'state' && e.data.rev === put.rev), 'verzender krijgt geen echo');

  // bellen: A -> B
  const s1 = await call('POST', '/api/signal', { to: hb.cid, data: { to: hb.cid, t: 'offer' } }, admin.token, ha.cid);
  assert.equal(s1.status, 200);
  const sig = await B.waitFor('sig');
  assert.equal(sig.from, ha.cid);
  assert.equal(sig.mid, admin.user.mid, 'afzender wordt door de server vastgesteld');
  assert.equal(sig.data.t, 'offer');

  // niet naar een ander gezin, en niet met een verbinding van iemand anders
  assert.equal((await call('POST', '/api/signal', { to: ho.cid, data: {} }, admin.token, ha.cid)).status, 404);
  assert.equal((await call('POST', '/api/signal', { to: hb.cid, data: {} }, admin.token, hb.cid)).status, 409);

  // ophangen van B: A ziet de aanwezigheid veranderen
  B.close();
  await A.waitFor('peers', (p) => p.length === 1);
  A.close(); O.close();
});

test('iceServers en export alleen voor wie dat mag', async () => {
  const ice = await call('GET', '/api/ice', null, admin.token);
  assert.ok(ice.iceServers.length >= 1);
  const l = await call('POST', '/api/login', { code, name: 'Mama', password: '2468' });
  assert.equal((await call('GET', '/api/export', null, l.token)).status, 403);
  const ex = await call('GET', '/api/export', null, admin.token);
  assert.equal(ex.status, 200);
  assert.ok(ex.accounts.length >= 2);
  assert.equal((await call('POST', '/api/newcode', {}, l.token)).status, 403);
  const nc = await call('POST', '/api/newcode', {}, admin.token);
  assert.notEqual(nc.code, code);
  assert.equal((await call('POST', '/api/join', { code, name: 'Oudecode', password: '1234' })).status, 404, 'oude code werkt niet meer');
});

test('bestanden van de app worden veilig geserveerd', async () => {
  const root = await fetch(base + '/');
  assert.equal(root.status, 200);
  assert.match(root.headers.get('content-type'), /text\/html/);
  const html = await root.text();
  assert.ok(html.includes('net.js'));
  const js = await fetch(base + '/net.js');
  assert.equal(js.status, 200);
  assert.match(js.headers.get('content-type'), /javascript/);
  assert.equal((await fetch(base + '/sw.js')).headers.get('cache-control'), 'no-cache');
  for (const bad of ['/../server.js', '/%2e%2e/server.js', '/..%2fserver.js', '/data/db.json', '/nope.html']) {
    const r = await fetch(base + bad);
    assert.ok([403, 404].includes(r.status), bad + ' -> ' + r.status);
    const t = await r.text();
    assert.ok(!t.includes('createServer') && !t.includes('families'), bad + ' lekt niets');
  }
  assert.equal((await call('GET', '/api/bestaatniet', null, admin.token)).status, 404);
  assert.equal((await fetch(base + '/api/state', { method: 'DELETE' })).status, 401);
});

test('gegevens worden opgeslagen en wachtwoorden staan niet leesbaar in het bestand', async () => {
  await new Promise((r) => setTimeout(r, 500));
  const raw = fs.readFileSync(path.join(DATA, 'db.json'), 'utf8');
  assert.ok(raw.includes('Familie Test'));
  for (const pw of ['veiligwachtwoord', '1234', '2468', '4321', '5555', '7777']) assert.ok(!raw.includes(`"${pw}"`), 'wachtwoord in klare tekst: ' + pw);
  assert.ok(raw.includes('"hash"'));
});

test('gezin verwijderen wist alles', async () => {
  assert.equal((await call('POST', '/api/delete-family', { password: 'fout' }, admin.token)).status, 403);
  assert.equal((await call('POST', '/api/delete-family', { password: 'veiligwachtwoord' }, admin.token)).status, 200);
  assert.equal((await call('GET', '/api/state', null, admin.token)).status, 401);
  await new Promise((r) => setTimeout(r, 500));
  assert.ok(!fs.readFileSync(path.join(DATA, 'db.json'), 'utf8').includes('Familie Test'));
});
